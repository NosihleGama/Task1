// Function to display the clicked button value on the screen
function dispalyOnScreen(value) {
    document.getElementById("inputbox").value += value;
}

// Function to clear the display
function ClearDisplay(value) {
    document.getElementById("inputbox").value = "";
}

// Function to perform calculation when the '=' button is clicked
function calculate() {
    try {
        let result = eval(document.getElementById("inputbox").value);
        document.getElementById("inputbox").value = result;
    } catch (error) {
        document.getElementById("inputbox").value = "Error";
    }
}
